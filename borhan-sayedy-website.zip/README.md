# Publishing this site on GitHub Pages

## 1. Create the repository
1. Go to github.com and sign in (create a free account if you don't have one).
2. Click **New repository**.
3. Name it **exactly** `<your-username>.github.io` — for example, if your username is `borhansayedy`, name the repo `borhansayedy.github.io`.
4. Set it to **Public**, and click **Create repository**.

## 2. Upload the files
1. On the repo's page, click **Add file → Upload files**.
2. Drag in **every file in this folder** (all the `.html`, `.css`, `.js`, `.jpg`, and `.csv` files) directly, no subfolder needed, they all sit at the top level of the repo.
3. Click **Commit changes**.

## 3. Turn on Pages (usually automatic)
1. Go to the repo's **Settings → Pages**.
2. Under "Build and deployment," make sure the source is set to **Deploy from a branch**, branch `main`, folder `/ (root)`.
3. Save. Within a minute or two, your site is live at `https://<your-username>.github.io`.

## Notes for later edits
- **Images and the CSV live at the repo root** (`photo.jpg`, `wordcloud.jpg`, `income-expense-template.csv`), not in a subfolder. Keep any new images or downloads at the root too, and reference them in HTML as just `filename.ext`, not `assets/filename.ext`.
- **Custom `.io` domain:** if you later buy an actual `.io` domain, add a file named `CNAME` (no extension) containing just your domain name, and point your domain's DNS to GitHub Pages. No other changes needed.
